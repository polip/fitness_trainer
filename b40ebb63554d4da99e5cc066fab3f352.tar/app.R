library(shiny)
library(bslib)
library(tidyverse)
library(ellmer)  # For LLM integration
library(pagedown) # For HTML to PDF conversion

# Set a default API key directly in the code
DEFAULT_API_KEY <- Sys.getenv("ANTHROPIC_API_KEY")

# Set up the UI
ui <- page_sidebar(
  title = "STAY HARD - AI Fitness Plan Generator",
  sidebar = sidebar(
    width = 300,
    
    # Personal Information
    accordion(
      accordion_panel(
        "Personal Information",
        selectInput("gender", "Gender",choices = c('Male','Female') ),
        sliderInput("age", "Age", value = 40, min = 14, max = 100),
        sliderInput("weight", "Weight (kg)", value = 99, min = 30, max = 200),
        sliderInput("height", "Height (cm)", value = 185, min = 100, max = 250)
        
      ),  
      
      # Fitness Goals
      accordion_panel(
        "Fitness Goals",
        selectInput("training_type", "Type of Training", 
                    choices = c("Strength", "Hypertrophy", "Weight Loss", "Endurance", 
                                "Functional", "General Fitness")),
        selectInput("experience", "Experience Level", 
                    choices = c("Beginner", "Intermediate", "Advanced")),
        selectInput("frequency", "Training Frequency", 
                    choices = c("2-3 days/week", "3-4 days/week", "4-5 days/week", "5+ days/week")),
        textAreaInput("goals", "Specific Goals (optional)", 
                      placeholder = "e.g., Run a 5K, Build bigger arms, Improve posture...")
        
      ),
      # Health Considerations
      
      accordion_panel(
        "Health Considerations",
        textAreaInput("limitations", "Injuries or Limitations (if any)", 
                      placeholder = "e.g., Bad knees, Lower back pain..."),
        selectInput("equipment", "Available Equipment", 
                    choices = c("Full Gym", "Home Gym Basics", "Minimal/Bodyweight Only"))
        
      )
    ),
    
    
    # Generate Button
    actionButton("generate", "Generate Fitness Plan", class = "btn-primary btn-lg", 
                 width = "100%", icon = icon("dumbbell")),
    # Download Button
    downloadButton("downloadPDF", "Download as PDF", class = "btn-secondary btn-lg", 
                   width = "100%", icon = icon("download")),
  ),
  
  # Main Panel
  card(
    card_header("Your Personalized Fitness Plan"),
    card_body(
      textOutput("loading_text"),
      uiOutput("fitness_plan_ui")
    )
  )
)

# Server logic
server <- function(input, output, session) {
  
  # Reactive value to store the fitness plan
  fitness_plan <- reactiveVal("")
  
  # Show loading message when generating
  output$loading_text <- renderText({
    if(input$generate > 0) {
      "Generating your personalized fitness plan... This may take a few moments."
    } else {
      "Enter your information and click 'Generate Fitness Plan' to get started."
    }
  })
  
  # Generate fitness plan when button is clicked
  observeEvent(input$generate, {
    # Construct the user profile from inputs
    user_profile <- tibble(
      age = input$age,
      gender=input$gender,
      weight = input$weight,
      height = input$height,
      training_type = input$training_type,
      experience = input$experience,
      frequency = input$frequency,
      goals = if(input$goals == "") "General fitness improvement" else input$goals,
      limitations = if(input$limitations == "") "None" else input$limitations,
      equipment = input$equipment
    )
    
    # System prompt for Claude AI
    system_prompt <- "You are a professional fitness trainer and nutrition specialist with expertise in creating personalized workout plans. You provide detailed, evidence-based fitness advice tailored to individual needs and goals. Your recommendations are practical, safe, and effective for people of all fitness levels."
    
    # Create user prompt for Claude
    user_prompt <- glue::glue(
      "Create a detailed 4-week fitness plan for {user_profile$age} years old {user_profile$gender}, 
      weighing {user_profile$weight}kg and {user_profile$height}cm tall. Each daily workout should contain at least 8 exercises.
      
      
      Training type: {user_profile$training_type}
      Experience level: {user_profile$experience}
      Training frequency: {user_profile$frequency}
      Specific goals: {user_profile$goals}
      Limitations/injuries: {user_profile$limitations}
      Available equipment: {user_profile$equipment}
      
      The plan should include:
      1. Initial assesment of fitness
      2. A weekly workout schedule
      3. Detailed exercises for each workout day from weekly plan
      4. Sets, reps, rest periods, RPM
      5. Instructions for each exercise
      6. Progression scheme over the 4 weeks
      7. Detailed nutrition recommendations
      8. Recovery tips
      9. Motivation tips
      10. Some jokes
      
      
      Format the response in markdown with clear headings and sections."
    )
    
    # LLM call to generate fitness plan (using ellmer package with Claude)
    # Wrapping in tryCatch to handle potential errors
    plan_result <- tryCatch({
      # Call the Claude AI with the prompt using the pre-configured API key
      # Note: For Claude, we need to use the Anthropic API which has a different format
      # Using ellmer package with Claude model
      chat <- ellmer::chat_claude(
        model = 'claude-3-5-sonnet-20241022',
        max_tokens = 2000,
        api_key = DEFAULT_API_KEY,  # Using the pre-configured API key
        system = system_prompt  # Adding system prompt for Claude
      )
      
      llm_response <- chat$chat(user_prompt)   
      
      # For testing/demo purposes, we'll also include a mock response
      # as a fallback in case the API call doesn't work
      if (is.null(llm_response) || llm_response == "") {stop('LLM response not created!')} else {
        llm_response
      }
    }, error = function(e) {
      paste("Error generating fitness plan:", e$message, 
            "\n\nPlease try again or contact the app administrator if the error persists.")
    })
    
    # Store the generated plan
    fitness_plan(plan_result) ### reactive value
    
    # Update the UI with the markdown content
    output$fitness_plan_ui <- renderUI({
      if(input$generate > 0) {
        HTML(markdown::markdownToHTML(text = fitness_plan(), fragment.only = TRUE))
      }
    })
  })
  
  # PDF Download handler
  output$downloadPDF <- downloadHandler(
    filename = function() {
      paste("fitness-plan-", format(Sys.Date(), "%Y-%m-%d"), ".pdf", sep = "")
    },
    content = function(file) {
      # Don't try to create a PDF if no plan has been generated
      if (fitness_plan() == "") {
        showNotification("Please generate a fitness plan first", type = "error")
        return()
      }
      
      # Create temporary HTML file
      tempHTML <- tempfile(fileext = ".html")
      
      # Create a full HTML document with the fitness plan content
      html_content <- paste0(
        "<!DOCTYPE html>
        <html>
        <head>
          <meta charset='UTF-8'>
          <meta name='viewport' content='width=device-width, initial-scale=1.0'>
          <title>Your Fitness Plan</title>
          <style>
            body { 
              font-family: Arial, sans-serif;
              line-height: 1.6;
              margin: 20px;
              max-width: 800px;
              margin: 0 auto;
              padding: 20px;
            }
            h1, h2, h3 { color: #333; }
            h1 { border-bottom: 2px solid #333; padding-bottom: 10px; }
            h2 { margin-top: 20px; }
            table { border-collapse: collapse; width: 100%; margin: 15px 0; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
            ul, ol { margin-left: 20px; }
          </style>
        </head>
        <body>",
        markdown::markdownToHTML(text = fitness_plan(), fragment.only = TRUE),
        "</body></html>"
      )
      
      # Write the HTML content to the temporary file
      writeLines(html_content, tempHTML)
      
      # Convert HTML to PDF using pagedown
      tryCatch({
        pagedown::chrome_print(tempHTML, output = file)
      }, error = function(e) {
        # Fallback if pagedown fails
        showNotification(paste("Error creating PDF:", e$message), type = "error")
      })
      
      # Clean up
      unlink(tempHTML)
    },
    contentType = "application/pdf"
  )
}

# Run the application
shinyApp(ui = ui, server = server)
